﻿using UnityEngine;
using System.Collections;

public class BouncyBigSpritesBehaviourScript : MonoBehaviour
{
    public Sprite[] sprites;
}